Bug Fixes in Foxit Phantom 2.2.3
======================================================================================================================
1. Addressed a potential security vulnerability in PDFs containing certain objects including RunLengthDecode


Bug Fixes in Foxit Phantom 2.2.1 
======================================================================================================================
1. Fixed the crash issue when opening some PDF files
2. Fixed the crash issue upon continuous scanning


Bug Fixes and Improvements in Foxit Phantom 2.2
======================================================================================================================
1. Enhanced the security of digital signature
2. Fixed the bug where wrong time and date are displayed on special stamp in certain time zones



What's New in Foxit Phantom 2.1
======================================================================================================================
1. OCR text recognition. 
2. Add Header & Footer, Watermark & Background to PDFs. 
3. Create and manage digital signature field.
4. Bookmark creating in combining PDFs.
5. Choose PDF specification when creating PDF.
6. Search words in comments and bookmarks. 
7. Improve stamp tool.

Bug Fixes and Improvements in Foxit Phantom 2.1
======================================================================================================================
1. Fixed the issue where the digital signature is correctly verified only one time if certificates are not installed.  
2. Fixed the issue where only the first Signature field can be signed using the Sign Document menu if there are multiple Signature fields in the document. 
3. Fixed the issue of misreported document size for a scanned PDF document.
4. Fixed the issue where the units are inconsistent with the measurement Units setting in the preference for cropping pages. 
5. Added the business card size in scan settings.



What's New in Foxit Phantom 2.0
======================================================================================================================
1. Support database connectivity to windows ODBC.
2. Convert multiple files to PDFs or merge them into a single PDF file.
3. Change page order & print multiple pages with thumbnails.
4. Insert blank pages or pages from scanner.
5. Set initial view.
6. Easily edit document information. 
7. Manage annotations with ease.
8. Undo and Redo actions.
9. Support more image format.


Download the latest version
======================================================================================================================
Download the latest version of Foxit Phantom after online registration at http://www.foxitsoftware.com/pdf/phantom/register.php


Contact Us
======================================================================================================================
If you have any questions using Foxit Phantom, please feel free to contact us:

Sales and Information - sales@foxitsoftware.com
Marketing Service - marketing@foxitsoftware.com
Technical Support - support@foxitsoftware.com
Website Questions - webmaster@foxitsoftware.com


Foxit Corporation
Address: 39819 Paseo Padre Parkway, Fremont CA 94538, USA 
Sales Phone: 1-866-MYFOXIT or 1-866-693-6948 (8AM-5PM PST Monday - Friday) 
             510-438-9090 (8AM-5PM PST Monday - Friday)
Support Phone: 1-866-MYFOXIT or 1-866-693-6948 (24/7)
               979-446-0280 (6AM-5PM PST Monday - Friday)
Fax: 510-405-9288
Web: http://www.foxitsoftware.com
