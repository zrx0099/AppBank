readium-shared-js
=================

Repository for the shared JavaScript libraries that are used in the SDK-Launchers and other applications developed on top of the SDK
